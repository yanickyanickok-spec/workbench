const CACHE='bangdan-v2';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{
let url=new URL(e.request.url);
// 永远不缓存 data.json，保证拿到最新
if(url.pathname.endsWith('data.json')){
e.respondWith(fetch(e.request));
return;
}
e.respondWith(caches.open(CACHE).then(c=>c.match(e.request).then(r=>r||fetch(e.request).then(f=>{c.put(e.request,f.clone());return f}))));
});
